#!/bin/bash
# DuckDNS Dynamic DNS Updater
# Keeps your domain pointing to your home server's current public IP.
#
# Setup:
#   1. Register at https://www.duckdns.org
#   2. Create a subdomain (e.g. myradio.duckdns.org)
#   3. Fill in SUBDOMAIN and TOKEN below
#   4. chmod +x scripts/duckdns.sh
#   5. Add to crontab: */5 * * * * /path/to/duckdns.sh

SUBDOMAIN="your-subdomain-here"
TOKEN="your-duckdns-token-here"
LOG="/var/log/duckdns.log"

echo "[$(date)] Updating DuckDNS..." >> $LOG
RESULT=$(curl -s "https://www.duckdns.org/update?domains=${SUBDOMAIN}&token=${TOKEN}&ip=")
echo "[$(date)] Response: $RESULT" >> $LOG
