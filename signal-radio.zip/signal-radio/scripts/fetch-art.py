#!/usr/bin/env python3
"""
fetch-art.py — Auto-fetch and embed cover art for your music library.
Uses the iTunes Search API (free, no key required).

Usage:
    python3 scripts/fetch-art.py /path/to/music

Requirements:
    pip3 install eyeD3 --break-system-packages
    export PATH="$HOME/.local/bin:$PATH"
"""

import os
import sys
import json
import urllib.request
import urllib.parse
import subprocess

def fetch_art(music_dir):
    eyeD3 = os.path.expanduser("~/.local/bin/eyeD3")
    if not os.path.exists(eyeD3):
        print("eyeD3 not found. Install with: pip3 install eyeD3 --break-system-packages")
        sys.exit(1)

    files = [f for f in os.listdir(music_dir) if f.lower().endswith('.mp3')]
    print(f"Found {len(files)} MP3 files\n")

    ok, skipped = 0, 0

    for filename in sorted(files):
        filepath = os.path.join(music_dir, filename)
        trackname = filename.replace('.mp3', '')[:80]
        query = urllib.parse.quote(trackname)
        url = f"https://itunes.apple.com/search?term={query}&media=music&limit=1"

        try:
            with urllib.request.urlopen(url, timeout=6) as r:
                data = json.loads(r.read())

            if data["resultCount"] > 0:
                art_url = data["results"][0]["artworkUrl100"].replace("100x100bb", "600x600bb")
                art_path = "/tmp/signal_cover.jpg"
                urllib.request.urlretrieve(art_url, art_path)
                result = subprocess.run(
                    [eyeD3, "--add-image", f"{art_path}:FRONT_COVER", filepath],
                    capture_output=True
                )
                print(f"  ✓  {filename}")
                ok += 1
            else:
                print(f"  ✗  {filename} (no match)")
                skipped += 1

        except Exception as e:
            print(f"  ✗  {filename} ({e})")
            skipped += 1

    print(f"\nDone. {ok} tagged, {skipped} skipped.")
    print("Rescan Navidrome: http://localhost:4533 → Settings → Scanning → Scan Now")

if __name__ == "__main__":
    music_dir = sys.argv[1] if len(sys.argv) > 1 else "/music"
    if not os.path.isdir(music_dir):
        print(f"Directory not found: {music_dir}")
        sys.exit(1)
    fetch_art(music_dir)
