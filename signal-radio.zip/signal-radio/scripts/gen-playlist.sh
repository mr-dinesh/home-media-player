#!/bin/bash
# gen-playlist.sh — Generate default.m3u from all music in ./music folder
# Run this after adding new tracks to automatically rebuild the playlist.
#
# Usage: bash scripts/gen-playlist.sh

MUSIC_DIR="./music"
PLAYLIST_DIR="./playlists"
OUTPUT="$PLAYLIST_DIR/default.m3u"

mkdir -p "$PLAYLIST_DIR"

echo "#EXTM3U" > "$OUTPUT"
find "$MUSIC_DIR" -type f \( -name "*.mp3" -o -name "*.aac" -o -name "*.ogg" -o -name "*.flac" -o -name "*.m4a" \) \
  | sort \
  | sed "s|$MUSIC_DIR|/music|g" \
  >> "$OUTPUT"

COUNT=$(grep -c "^/" "$OUTPUT" 2>/dev/null || echo 0)
echo "Generated $OUTPUT with $COUNT tracks."
echo "Liquidsoap will pick up changes within 10 seconds."
