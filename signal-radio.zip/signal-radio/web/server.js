const express = require('express');
const fs = require('fs');
const path = require('path');
const net = require('net');
const multer = require('multer');

const app = express();
const PORT = 3000;
const MUSIC_DIR = '/music';
const PLAYLIST_DIR = '/playlists';

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// ── File upload ───────────────────────────────
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, MUSIC_DIR),
  filename: (req, file, cb) => cb(null, file.originalname)
});
const upload = multer({
  storage,
  fileFilter: (req, file, cb) => {
    const allowed = ['.mp3', '.aac', '.ogg', '.flac', '.m4a'];
    cb(null, allowed.includes(path.extname(file.originalname).toLowerCase()));
  }
});

// ── Liquidsoap telnet control ─────────────────
function sendLiquidsoapCommand(cmd) {
  return new Promise((resolve, reject) => {
    const client = new net.Socket();
    let response = '';
    client.connect(1234, 'liquidsoap', () => client.write(cmd + '\n'));
    client.on('data', d => {
      response += d.toString();
      if (response.includes('END')) {
        client.destroy();
        resolve(response.replace(/END\n?/g, '').trim());
      }
    });
    client.on('error', reject);
    setTimeout(() => { client.destroy(); resolve(response.trim()); }, 2000);
  });
}

// Skip current track
app.post('/api/control/skip', async (req, res) => {
  try {
    await sendLiquidsoapCommand('main_playlist.skip');
    res.json({ ok: true });
  } catch(e) { res.status(500).json({ error: e.message }); }
});

// Now playing (returns RID of current request)
app.get('/api/control/nowplaying', async (req, res) => {
  try {
    const r = await sendLiquidsoapCommand('request.on_air');
    res.json({ ok: true, track: r });
  } catch(e) { res.status(500).json({ error: e.message }); }
});

// ── Music library ─────────────────────────────
app.get('/api/music', (req, res) => {
  try {
    const files = fs.readdirSync(MUSIC_DIR)
      .filter(f => ['.mp3','.aac','.ogg','.flac','.m4a'].includes(path.extname(f).toLowerCase()))
      .map(f => ({
        name: f,
        path: path.join(MUSIC_DIR, f),
        size: fs.statSync(path.join(MUSIC_DIR, f)).size
      }));
    res.json(files);
  } catch(e) { res.json([]); }
});

app.post('/api/music/upload', upload.array('files'), (req, res) => {
  res.json({ uploaded: req.files.map(f => f.originalname) });
});

app.delete('/api/music/:filename', (req, res) => {
  const fp = path.join(MUSIC_DIR, req.params.filename);
  if (fs.existsSync(fp)) { fs.unlinkSync(fp); res.json({ ok: true }); }
  else res.status(404).json({ error: 'Not found' });
});

// ── Playlists ─────────────────────────────────
app.get('/api/playlists', (req, res) => {
  try {
    const files = fs.readdirSync(PLAYLIST_DIR)
      .filter(f => f.endsWith('.m3u'))
      .map(f => {
        const content = fs.readFileSync(path.join(PLAYLIST_DIR, f), 'utf8');
        const tracks = content.split('\n').filter(l => l && !l.startsWith('#'));
        return { name: f.replace('.m3u',''), filename: f, trackCount: tracks.length };
      });
    res.json(files);
  } catch(e) { res.json([]); }
});

app.get('/api/playlists/:name', (req, res) => {
  const fp = path.join(PLAYLIST_DIR, req.params.name + '.m3u');
  if (!fs.existsSync(fp)) return res.status(404).json({ error: 'Not found' });
  const lines = fs.readFileSync(fp, 'utf8').split('\n').filter(l => l && !l.startsWith('#'));
  res.json({ name: req.params.name, tracks: lines });
});

app.post('/api/playlists', (req, res) => {
  const { name, tracks } = req.body;
  if (!name) return res.status(400).json({ error: 'Name required' });
  fs.writeFileSync(path.join(PLAYLIST_DIR, name + '.m3u'), '#EXTM3U\n' + (tracks||[]).join('\n'));
  res.json({ ok: true, name });
});

app.put('/api/playlists/:name', (req, res) => {
  const { tracks } = req.body;
  fs.writeFileSync(path.join(PLAYLIST_DIR, req.params.name + '.m3u'), '#EXTM3U\n' + (tracks||[]).join('\n'));
  res.json({ ok: true });
});

app.delete('/api/playlists/:name', (req, res) => {
  const fp = path.join(PLAYLIST_DIR, req.params.name + '.m3u');
  if (fs.existsSync(fp)) { fs.unlinkSync(fp); res.json({ ok: true }); }
  else res.status(404).json({ error: 'Not found' });
});

// ── Active broadcast playlist ─────────────────
app.post('/api/active', (req, res) => {
  const { name } = req.body;
  const fp = path.join(PLAYLIST_DIR, name + '.m3u');
  if (!fs.existsSync(fp)) return res.status(404).json({ error: 'Playlist not found' });
  fs.writeFileSync(path.join(PLAYLIST_DIR, 'active.txt'), fp);
  fs.copyFileSync(fp, path.join(PLAYLIST_DIR, 'default.m3u'));
  res.json({ ok: true, active: name });
});

app.get('/api/active', (req, res) => {
  const fp = path.join(PLAYLIST_DIR, 'active.txt');
  if (!fs.existsSync(fp)) return res.json({ active: null });
  const active = path.basename(fs.readFileSync(fp,'utf8').trim(), '.m3u');
  res.json({ active });
});

// ── Icecast status proxy ──────────────────────
app.get('/api/status', async (req, res) => {
  try {
    const http = require('http');
    const data = await new Promise((resolve, reject) => {
      http.get('http://icecast:8000/status-json.xsl', r => {
        let body = '';
        r.on('data', d => body += d);
        r.on('end', () => resolve(body));
      }).on('error', reject);
    });
    res.json(JSON.parse(data));
  } catch(e) { res.json({ error: 'Icecast not reachable' }); }
});

// ── Init ──────────────────────────────────────
if (!fs.existsSync(PLAYLIST_DIR)) fs.mkdirSync(PLAYLIST_DIR, { recursive: true });
const defaultPl = path.join(PLAYLIST_DIR, 'default.m3u');
if (!fs.existsSync(defaultPl)) fs.writeFileSync(defaultPl, '#EXTM3U\n');

app.listen(PORT, () => console.log(`Radio Web UI running on :${PORT}`));
